Configuration DiskInitialization 
{
  param
  (
    [string]
    $disk_list,

    [string]
    $computer_name = $ENV:COMPUTERNAME
  )
    
  Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
  Configuration DiskInitialization 
{
  param
  (
    [string]
    $disk_list,

    [string]
    $computer_name = $ENV:COMPUTERNAME
  )
    
  Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
  Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
  Find-Module -Name StorageDsc -Repository PSGallery | Install-Module -Force
  Find-Module -Name cMoveAzureTempDrive -Repository PSGallery | Install-Module -Force
  Import-DSCResource -ModuleName StorageDsc
  Import-DSCResource -ModuleName cMoveAzureTempDrive

  $json = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($disk_list))
  $disks = ConvertFrom-Json $json

  Node localhost
  {
    OpticalDiskDriveLetter SetOpticalDiskDriveLetterToY
    {
      DiskId      = 1
      DriveLetter = 'Y'
    }

    cMoveAzureTempDrive SetAzureTempDriveLetterToZ
    {
      Name            = $computer_name
      TempDriveLetter = 'Z'
    }

    foreach ($disk in $disks)
    {
      WaitForDisk $disk.label
      {
        DiskId           = (Get-Disk | Where-Object Location -Match "LUN $($disk.LUN)" | Select-Object -ExpandProperty UniqueId)
        DiskIdType       = "UniqueId"
        RetryIntervalSec = 30
        RetryCount       = 10
        DependsOn        = "[cMoveAzureTempDrive]SetAzureTempDriveLetterToZ"
      }

      Disk $disk.label
      {
        DiskId             = (Get-Disk | Where-Object Location -Match "LUN $($disk.LUN)" | Select-Object -ExpandProperty UniqueId)
        DiskIdType         = "UniqueId"
        PartitionStyle     = "GPT"
        DriveLetter        = $disk.letter
        FSLabel            = $disk.label
        FSFormat           = "NTFS"
        AllocationUnitSize = $disk.AUSize
        AllowDestructive   = $false
        DependsOn          = "[WaitForDisk]$($disk.label)"
      }
    }
  }
}
  Find-Module -Name StorageDsc -Repository PSGallery | Install-Module -Force
  Find-Module -Name cMoveAzureTempDrive -Repository PSGallery | Install-Module -Force
  Import-DSCResource -ModuleName StorageDsc
  Import-DSCResource -ModuleName cMoveAzureTempDrive

  $json = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($disk_list))
  $disks = ConvertFrom-Json $json

  Node localhost
  {
    OpticalDiskDriveLetter SetOpticalDiskDriveLetterToY
    {
      DiskId      = 1
      DriveLetter = 'Y'
    }

    cMoveAzureTempDrive SetAzureTempDriveLetterToZ
    {
      Name            = $computer_name
      TempDriveLetter = 'Z'
    }

    foreach ($disk in $disks)
    {
      WaitForDisk $disk.label
      {
        DiskId           = (Get-Disk | Where-Object Location -Match "LUN $($disk.LUN)" | Select-Object -ExpandProperty UniqueId)
        DiskIdType       = "UniqueId"
        RetryIntervalSec = 30
        RetryCount       = 10
        DependsOn        = "[cMoveAzureTempDrive]SetAzureTempDriveLetterToZ"
      }

      Disk $disk.label
      {
        DiskId             = (Get-Disk | Where-Object Location -Match "LUN $($disk.LUN)" | Select-Object -ExpandProperty UniqueId)
        DiskIdType         = "UniqueId"
        PartitionStyle     = "GPT"
        DriveLetter        = $disk.letter
        FSLabel            = $disk.label
        FSFormat           = "NTFS"
        AllocationUnitSize = $disk.AUSize
        AllowDestructive   = $false
        DependsOn          = "[WaitForDisk]$($disk.label)"
      }
    }
  }
}